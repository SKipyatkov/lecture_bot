BEGIN TRANSACTION;
CREATE TABLE ab_testing (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    test_name TEXT,
                    group_name TEXT,
                    success BOOLEAN,
                    metrics TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );
CREATE TABLE admin_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    logout_time TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );
INSERT INTO "admin_sessions" VALUES(1,5389366665,'2025-09-01 14:09:49','2025-09-01 14:30:27');
INSERT INTO "admin_sessions" VALUES(2,5288263305,'2025-09-01 14:12:45','2025-09-01 14:12:53');
INSERT INTO "admin_sessions" VALUES(3,5389366665,'2025-09-01 14:29:18','2025-09-01 14:30:27');
INSERT INTO "admin_sessions" VALUES(4,5389366665,'2025-09-01 14:31:10','2025-09-01 14:32:32');
INSERT INTO "admin_sessions" VALUES(5,5389366665,'2025-09-01 14:32:25','2025-09-01 14:32:32');
INSERT INTO "admin_sessions" VALUES(6,5389366665,'2025-09-01 14:47:10','2025-09-01 15:11:47');
INSERT INTO "admin_sessions" VALUES(7,5389366665,'2025-09-01 15:11:39','2025-09-01 15:11:47');
INSERT INTO "admin_sessions" VALUES(8,5389366665,'2025-09-01 16:07:08','2025-09-01 16:07:40');
INSERT INTO "admin_sessions" VALUES(9,5389366665,'2025-09-01 16:27:39','2025-09-01 17:51:01');
INSERT INTO "admin_sessions" VALUES(10,5389366665,'2025-09-01 17:50:49','2025-09-01 17:51:01');
INSERT INTO "admin_sessions" VALUES(11,5389366665,'2025-09-02 04:03:45','2025-09-02 04:04:12');
INSERT INTO "admin_sessions" VALUES(12,5389366665,'2025-09-02 05:21:10','2025-09-02 05:21:36');
INSERT INTO "admin_sessions" VALUES(13,5389366665,'2025-09-02 08:49:50','2025-09-03 13:58:22');
INSERT INTO "admin_sessions" VALUES(14,5389366665,'2025-09-03 13:57:49','2025-09-03 13:58:22');
INSERT INTO "admin_sessions" VALUES(15,5389366665,'2025-09-04 10:18:39','2025-09-04 10:21:54');
INSERT INTO "admin_sessions" VALUES(16,5389366665,'2025-09-04 15:24:47','2025-09-05 07:42:30');
INSERT INTO "admin_sessions" VALUES(17,5389366665,'2025-09-05 07:42:10','2025-09-05 07:42:30');
INSERT INTO "admin_sessions" VALUES(18,5389366665,'2025-10-06 04:13:22',NULL);
CREATE TABLE audio_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    file_id TEXT,
                    file_size INTEGER,
                    duration INTEGER,
                    recognized_text TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );
INSERT INTO "audio_requests" VALUES(1,5389366665,'AwACAgIAAxkBAAMjaLRzNDxGQOEuaC4DHx0Hua0NadUAAvx7AAICk6BJGsmMAtVGUDU2BA',10730,2.6735,'вот это проверка связи','2025-08-31 16:07:20');
INSERT INTO "audio_requests" VALUES(2,5389366665,'AwACAgIAAxkBAAMlaLRzs9dMWpDtL0pAhPJdmINOutcAAgp8AAICk6BJx8gAAZAfSXLzNgQ',15454,3.9335,'привет это проверка связи','2025-08-31 16:09:25');
INSERT INTO "audio_requests" VALUES(3,974556405,'AwACAgIAAxkBAAMtaLR2OXW0BnRoSXtTgxtdWeqRyAoAAmZ5AAJmOahJQ9fPe5Rdz5Q2BA',68622,17.9335,'ты блядь не представляешь какой я счастливый я короче я не тебе так говорю короче я нашёл штука которая на гитхабе воск короче сейчас скажу что это','2025-08-31 16:20:15');
INSERT INTO "audio_requests" VALUES(4,6242110030,'AwACAgIAAxkBAAMvaLR2Rv5LWVVGUptRuRZU711XAxgAAoeBAALUOaFJWoWcevudVIA2BA',22677,1.0535,'привет','2025-08-31 16:20:23');
INSERT INTO "audio_requests" VALUES(5,1088667912,'AwACAgIAAxkBAAMzaLR2nke5t8wd-d9WWumL9EH3yyYAAqCBAAKlY6BJpm645BujyhE2BA',52527,2.6135,'привет пора уже спать','2025-08-31 16:21:52');
INSERT INTO "audio_requests" VALUES(6,941113842,'CQACAgIAAxkBAAM1aLR2wSBxQTTxI4Xk0EhJ3xVTW-kAAgx8AAJ0QaBJlvtxfePLj5U2BA',9397812,234.945313,'бостон не знаю поскольку вижу что джо бостоне и сам не знаю что мне нужно просто остаться засыпай создана сюжет жаль меня боялись смотреть в пустоту без таблеток ты видела моря я видел тебя нам только и отблески света никто не увидит как мы задавай покажи им как нужно любить я тоже встречал тебя тысячу раз замечая в других знаешь прекрасно я не был один капилляры я тебя тоже когда-то терял дорогая меня тоже когда-то издало вплетается вечная сети места где мы были вдвоём опираясь в памяти мои джуманджи у тебя чтобы помочь засыпай я создала для меня сюжет создана жаль меня мечелет мы притворяемся что мы знакомы меняем друзей отрицать телефоны выбрасывая вещи из паспорта казалось ты пахнешь весной казалось что ты навсегда казалось ты рядом мы можем летать что может быть а то придётся ты откроешь глаза мне руками но капилляры я тебя тоже когда-то терял дорогая меня тоже когда-то не знал отвлекает меня вечная здесь звезда где мы были вдвоём опираясь на памятные рамы дешёвым вином мои друга живу вы помочь нам друг друга не засыпай да для меня жизнь да жаль меня да ну','2025-08-31 16:24:07');
INSERT INTO "audio_requests" VALUES(7,1088667912,'AwACAgIAAxkBAAM3aLR23PUm4nNX9xqqCZZfxS6xiqQAAmt8AAIgYKlJdvnjKlOx8ME2BA',9223,2.1935,'привет сегодня буду поздно','2025-08-31 16:24:08');
INSERT INTO "audio_requests" VALUES(8,5288263305,'AwACAgIAAxkBAAM_aLR5ilDgo1zsHr79SOB6x4dV02IAAtCCAAJMxahJW6ovdDKPFaw2BA',15433,3.8935,'хуй пизда привет пока','2025-08-31 16:34:19');
INSERT INTO "audio_requests" VALUES(9,685827385,'AwACAgIAAxkBAANNaLUpy0xhtKiY8MOg6Lye_R-QYaMAAhV5AAIgNKlJ-0iCPWziV1Q2BA',19979,1.0335,'команд загера','2025-09-01 05:06:24');
INSERT INTO "audio_requests" VALUES(10,1013833242,'AwACAgIAAxkBAANPaLUxJd5Z_sRdxKsmwtZHHWA81usAAoFwAALkS5hJEcH48fmnV7U2BA',1273097,61.7535,'по поводу крокодилы честно я думала они будут прям долго отгадывать слова а некоторые они отгадывали ну немного быстрее можно было реально либо посложнее взять либо больше каких-то таких студенческих я не знаю слов приколю чтобы они ещё отгадывали не знаю мне кажется они бы вообще не отгадали я бы взял вот но на практике вообще обычно показывают что расписанием которое скидывают предварительно оно обычно сохраняется но посмотрим у меня но пока я приедем через понедельник я ни что не четверг а вот и стремление к сожалению по четыре пары поэтому ну там знаете такие преподаватели что мне попкой я наверное будут ходить один два раза в неделю точно а в остальные по желанию и по настроению вот поэтому понедельник четверг сто процентов могу','2025-09-01 06:32:06');
INSERT INTO "audio_requests" VALUES(11,998775808,'AwACAgIAAxkBAANTaLU-Ad2ZDmQMb8ZNWe7cmZWg-ecAAll1AALkhqhJ8x6LNAucXHc2BA',13267,3.1335,'привет меня зовут галина я','2025-09-01 06:32:37');
INSERT INTO "audio_requests" VALUES(12,685827385,'AwACAgIAAxkBAANiaLVWSmjg9-6tmlPoOTssqFvpMVIAAg2FAAJqY6hJw0to7JkzVUk2BA',211147,10.3135,'это ты за нас напишешь мне сразу я настя волос ещё написал просто то что я артём саша блядь а вы написали полина только за тебя написал обо все','2025-09-01 08:16:32');
INSERT INTO "audio_requests" VALUES(13,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:17:42');
INSERT INTO "audio_requests" VALUES(14,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:17:55');
INSERT INTO "audio_requests" VALUES(15,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:18:05');
INSERT INTO "audio_requests" VALUES(16,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:18:24');
INSERT INTO "audio_requests" VALUES(17,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:18:43');
INSERT INTO "audio_requests" VALUES(18,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:19:13');
INSERT INTO "audio_requests" VALUES(19,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:19:30');
INSERT INTO "audio_requests" VALUES(20,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:19:42');
INSERT INTO "audio_requests" VALUES(21,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:19:59');
INSERT INTO "audio_requests" VALUES(22,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:20:12');
INSERT INTO "audio_requests" VALUES(23,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:21:03');
INSERT INTO "audio_requests" VALUES(24,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:21:22');
INSERT INTO "audio_requests" VALUES(25,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:21:37');
INSERT INTO "audio_requests" VALUES(26,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:21:58');
INSERT INTO "audio_requests" VALUES(27,685827385,'AwACAgQAAxkBAANkaLVWnFEnBdKxgmfW6_LNsWDbXU4AAkwIAAK9lS1T5t8c6-lQY5A2BA',191821,15.766375,'просто представь брат мы с тобой бросаем все дела берём овощи шашлык и мчимся на природу представил а теперь забудь и иди дальше работать вообще размечтался фантазёр','2025-09-01 08:22:15');
INSERT INTO "audio_requests" VALUES(28,685827385,'AwACAgIAAxkBAAOUaLVYroSzPAmFaF7Y3nKGVS7eA7gAAtuJAAJKhqlJyi2-sXnz41A2BA',754887,104.77,'да была жива адже транши ладно ладно да бла бла бла сухо хуже от них пахнет цугом подойду к верхним и базини крутые ребята пиздец ахуенные давайте перейдём пожалуйста ты че ещё за лаем ебаный майс посмотри у него даже нету баленсиаги лана давай дадим ему шанс чувак скажи реально да да да сейчас попробую бля про уйбат баунс это пиздец сброса себе нахуй не позор нас что некоторое время спустя в гай-гай смотри ебать от него пахнет свой ага да брат мне кажется реально сто пациентов эта ночь просто утонуть надо братан чау подойди сюда помыкала бра дроуд рявкнул дала сделаю блейк бив че бля бля тупо ну хай по нем нереально чал да брал послушай его борта бриана в этой темке уже мобильная бля мы просто забрали байкершу в баке габбро факел сир поки печи абзаца отца си','2025-09-01 08:29:03');
INSERT INTO "audio_requests" VALUES(29,685827385,'AwACAgIAAxkBAAOUaLVYroSzPAmFaF7Y3nKGVS7eA7gAAtuJAAJKhqlJyi2-sXnz41A2BA',754887,104.77,'да была жива адже транши ладно ладно да бла бла бла сухо хуже от них пахнет цугом подойду к верхним и базини крутые ребята пиздец ахуенные давайте перейдём пожалуйста ты че ещё за лаем ебаный майс посмотри у него даже нету баленсиаги лана давай дадим ему шанс чувак скажи реально да да да сейчас попробую бля про уйбат баунс это пиздец сброса себе нахуй не позор нас что некоторое время спустя в гай-гай смотри ебать от него пахнет свой ага да брат мне кажется реально сто пациентов эта ночь просто утонуть надо братан чау подойди сюда помыкала бра дроуд рявкнул дала сделаю лейк бив че бля бля тупо ну хай по нем нереально чал да брал послушай его борта бриана в этой темке уже мобильная бля мы просто забрали байкершу в баке габбро факел сир поки печи абзаца отца си','2025-09-01 08:31:03');
INSERT INTO "audio_requests" VALUES(30,685827385,'AwACAgIAAxkBAAOUaLVYroSzPAmFaF7Y3nKGVS7eA7gAAtuJAAJKhqlJyi2-sXnz41A2BA',754887,104.77,'да была жива адже транши ладно ладно да бла бла бла сухо хуже от них пахнет цугом подойду к верхним и базини крутые ребята пиздец ахуенные давайте перейдём пожалуйста ты че ещё за лаем ебаный майс посмотри у него даже нету баленсиаги лана давай дадим ему шанс чувак скажи реально да да да сейчас попробую бля про уйбат баунс это пиздец сброса себе нахуй не позор нас что некоторое время спустя в гай-гай смотри ебать от него пахнет свой ага да брат мне кажется реально сто пациентов эта ночь просто утонуть надо братан чау подойди сюда помыкала бра дроуд рявкнул дала сделаю лейк бив че бля бля тупо ну хай по нем нереально чал да брал послушай его борта бриана в этой темке уже мобильная бля мы просто забрали байкершу в баке габбро факел сир поки печи абзаца отца си','2025-09-01 08:32:23');
INSERT INTO "audio_requests" VALUES(31,685827385,'AwACAgIAAxkBAAOUaLVYroSzPAmFaF7Y3nKGVS7eA7gAAtuJAAJKhqlJyi2-sXnz41A2BA',754887,104.77,'да была жива адже транши ладно ладно да бла бла бла сухо хуже от них пахнет цугом подойду к верхним и базини крутые ребята пиздец ахуенные давайте перейдём пожалуйста ты че ещё за лаем ебаный майс посмотри у него даже нету баленсиаги ладно давай дадим ему шанс чувак скажи реально да да да сейчас попробую бля про уйбат баунс это пиздец сброса себе нахуй не позор нас что некоторое время спустя в гай-гай смотри ебать от него пахнет свой ага да брат мне кажется реально сто пациентов эта ночь просто утонуть надо братан чау подойди сюда помыкала бра дроуд рявкнул дала сделаю блейк бив че бля бля тупо ну хай по нем нереально чал да брал послушай его борта бриана в этой темке уже мобильная бля мы просто забрали байкершу в баке габбро факел сир поки печи абзаца отца си','2025-09-01 08:33:37');
INSERT INTO "audio_requests" VALUES(32,685827385,'AwACAgIAAxkBAAOUaLVYroSzPAmFaF7Y3nKGVS7eA7gAAtuJAAJKhqlJyi2-sXnz41A2BA',754887,104.77,'да была жива адже транши ладно ладно да бла бла бла сухо хуже от них пахнет цугом подойду к верхним и плотине крутые ребята пиздец ахуенные давайте перейдём пожалуйста ты че ещё за лаем ебаный майс посмотри у него даже нету баленсиаги лана давай дадим ему шанс чувак скажи реально да да да сейчас попробую бля про уйбат баунс это пиздец сброса себе нахуй не позор нас что некоторое время спустя в гай-гай смотри ебать от него пахнет свой ага да брат мне кажется реально сто пациентов эта ночь просто утонуть надо братан чау подойди сюда помыкала бра дроуд рявкнул дала сделаю лейк бив че бля бля тупо ну хай по нем нереально чал да брал послушай его борта бриана в этой темке уже мобильная бля мы просто забрали байкершу в баке габбро факел сир поки печи абзаца отца си','2025-09-01 08:34:56');
INSERT INTO "audio_requests" VALUES(33,5389366665,'AwACAgIAAxkBAAOwaLVbavD8skOGZEJMtqUnrFwv7R8AAs56AAICk6hJsYYYEd9fpJc2BA',43136,11.7135,'поддержка пользователей за мальчиком простое упражнение среднего вы наверное можете работать по этому направлению','2025-09-01 08:38:19');
INSERT INTO "audio_requests" VALUES(34,5389366665,'AwACAgIAAxkBAAOyaLV5blIfXFnPxdACKF69rGDlJQsAAk58AAICk6hJmQNztvIVW-k2BA',14714,3.5335,'один два три четыре проверка связи','2025-09-01 10:46:24');
INSERT INTO "audio_requests" VALUES(35,5389366665,'AwACAgIAAxkBAAO0aLWBEGbARSar_yohTlrdrWhSDEUAAt18AAICk6hJM5rJjpqpGic2BA',6822,1.5535,'привет привет','2025-09-01 12:02:48');
INSERT INTO "audio_requests" VALUES(36,5389366665,'AwACAgIAAxkBAAO2aLWMEB4ubEA7XfLhtrsOwKrkL8UAAgF-AAICk6hJhnhO4UdD_B42BA',15863,3.9935,'саша не хочет меня ебать','2025-09-01 12:05:37');
INSERT INTO "audio_requests" VALUES(37,5389366665,'AwACAgIAAxkBAAO4aLWTkRl-tQK8a2KVBWajBsKAYRUAAsJ-AAICk6hJ8eYVPSmr8iw2BA',8903,2.1135,'гвай да','2025-09-01 12:37:40');
INSERT INTO "audio_requests" VALUES(38,5389366665,'AwACAgIAAxkBAAO6aLWTmneMJ3OBn9wNvlG8dooe4E0AAsR-AAICk6hJKuXJtWm1bfM2BA',6022,1.3335,'гойда','2025-09-01 12:37:47');
INSERT INTO "audio_requests" VALUES(39,5389366665,'AwACAgIAAxkBAAO8aLWTsWa6EkMbRpnxayQAAd-IMJPEAALtfgACamOwSTxFvIvNnBo_NgQ',558051,27.1535,'внутри в любом случае нам надо о себе заявить я получается я в кино вот если человек и отправит я же их не буду сразу куда-то звать так вижу то что это человек второго курса им говорю браток давай чуть-чуть попозже посмотрим потому что там вот то то то то ты ещё там к учёбе не приспособился или временно их там куда-то могу звать плюс в любом случае какое-то контент-план должен быть','2025-09-01 12:38:17');
INSERT INTO "audio_requests" VALUES(40,5389366665,'AwACAgIAAxkBAAPAaLWZzKOT86OV672XK9w2zVHTWmYAAmJ_AAICk6hJtyTCLdH2iXU2BA',21317,5.2335,'ля-ля-ля я семён лобанов у меня башка из картошки','2025-09-01 13:04:13');
INSERT INTO "audio_requests" VALUES(41,5389366665,'AwACAgIAAxkBAAPCaLWaieSF9vX4u59rAboKhm2EWvAAAnZ_AAICk6hJgkCyl2x2njY2BA',22590,5.9335,'я купил себе книгу эск юэль','2025-09-01 13:07:23');
INSERT INTO "audio_requests" VALUES(42,5389366665,'AwACAgIAAxkBAAPFaLWaurxcrzg3f2fUIcA2Tp6X9a8AAnx_AAICk6hJ_aCGcWhGCEM2BA',24796,6.5335,'проверка работает ли бот на таком расстоянии','2025-09-01 13:08:12');
INSERT INTO "audio_requests" VALUES(43,5389366665,'AwACAgIAAxkBAAIBVWi1yMnaEgeBV9fMSkwoRRw-d0iGAALkdwACApOwSWAcurx4eowQNgQ',16113,3.9935,'я сейчас взорвусь если это работает.','2025-09-01 16:24:47');
INSERT INTO "audio_requests" VALUES(44,5389366665,'AwACAgIAAxkBAAIBV2i1yN2yUgfGsR19cavrwLbwoTbAAALmdwACApOwSXRIFI0yt1CuNgQ',16313,4.0535,'он сказал, что это будет правильно.','2025-09-01 16:25:02');
INSERT INTO "audio_requests" VALUES(45,5389366665,'AwACAgIAAxkBAAIBWWi1yO524Nk-wH7OsvUl8liu1eiEAALpdwACApOwSX0rxYEaeeAgNgQ',10305,2.5135,'окей здесь есть гуд.','2025-09-01 16:25:20');
INSERT INTO "audio_requests" VALUES(46,5389366665,'AwACAgIAAxkBAAIBX2i1yPkxhrcrccZ6nAesTWfQ0s-bAALqdwACApOwScmQFAABYF0gDzYE',8770,2.0735,'окей здесь есть год.','2025-09-01 16:25:30');
INSERT INTO "audio_requests" VALUES(47,5389366665,'AwACAgIAAxkBAAIBd2i13Nomgrlm24fYtRkZDTUaDLBEAALBigAC93mwSWw6jdi8KxeBNgQ',9065,2.0935,'раз раз раз проверка связи.','2025-09-01 17:50:20');
INSERT INTO "audio_requests" VALUES(48,1088667912,'AwACAgIAAxkBAAIBuWi2hsxant0TgT0yzGi1sGwaYaEMAAK-dgACTp65SaaZl2ormXEQNgQ',18350,7.717813,'актриса ниткой ходила анти как это этот распорядок устраивает все равно собираются.','2025-09-02 08:44:19');
INSERT INTO "audio_requests" VALUES(49,5389366665,'AwACAgIAAxkBAAICAWi4FZ4BLthcAmFiUq-aAcHFDH4BAAKyfAACbNLBSctJ22MwoFuBNgQ',8956,2.1135,'Привет, проверка связи.','2025-09-03 10:17:09');
INSERT INTO "audio_requests" VALUES(50,5389366665,'AwACAgIAAxkBAAICCGi4FclZ0QPJ616G6UUvT8ubdRJvAAK1fAACbNLBSWY6oBfCOXuYNgQ',12866,3.1135,'hello my name is eminem. hello my name is eminem. hello my name is eminem.','2025-09-03 10:17:51');
INSERT INTO "audio_requests" VALUES(51,5389366665,'AwACAgIAAxkBAAICC2i4FeHXeXxa-_a6W1oC8LCHic3-AAK3fAACbNLBSSF63CnlCOVpNgQ',12802,3.2135,'hello my name is sasha. hello my name is sasha. hello my name is sasha. hello my name is sasha. hello my name is sasha','2025-09-03 10:18:16');
INSERT INTO "audio_requests" VALUES(52,5389366665,'AwACAgIAAxkBAAICEmi4FwwxvTPqRIh7vcIg4BZG7E2iAALCfAACbNLBSXpPqSQv4JJENgQ',7822,1.8135,'Хэллоу, Майнэйм, и Саша.','2025-09-03 10:23:11');
INSERT INTO "audio_requests" VALUES(53,5389366665,'AwACAgIAAxkBAAICGWi4GIaBegAB7pvo2eFoC7zK5JeCBAACz3wAAmzSwUkdeC1H0NOFpDYE',7149,1.6535,'hello my name is sasha','2025-09-03 10:29:27');
INSERT INTO "audio_requests" VALUES(54,5389366665,'AwACAgIAAxkBAAICIGi4GJHsEUMfLFnXbPCWR0ukz3JBAALQfAACbNLBSffQUcjvnNErNgQ',11757,2.9735,'привет проверка связи','2025-09-03 10:29:38');
INSERT INTO "audio_requests" VALUES(55,5389366665,'AwACAgIAAxkBAAMHaLgrvNaAAAG9OT4AAS0_S_GgsBCYzgACungAAuMdwEkECYYvoEDq9TYE',9597,2.3335,'ася подъем','2025-09-03 11:51:27');
INSERT INTO "audio_requests" VALUES(56,931836227,'AwACAgIAAxkBAAMkaLhLSrv1uYUiSgR5jg_a-NiiuukAAih9AAKwGcFJclneOazB09Q2BA',4743,0.9935,'бе-бе-бе','2025-09-03 14:06:04');
INSERT INTO "audio_requests" VALUES(57,1403556244,'AwACAgIAAxkBAAMxaLhPjgulVNexGcQlgaq6vu4HWNAAAs6FAAJ2aMBJFNjZUHaa-7M2BA',339536,16.4535,'всем привет меня зовут сашка и я немножко приболел поэтому сейчас я лечусь сейчас сижу на больничном и пью таблетки','2025-09-03 14:24:22');
INSERT INTO "audio_requests" VALUES(58,1403556244,'AwACAgIAAxkBAAM-aLhP0IVKeG0e2s5_glKYdWTVFGIAAtOFAAJ2aMBJ5p7YvPe5hVI2BA',277736,13.4535,'this entire arena seems to be laid off like a clock with new threats every hour but they stay only within the rich it all starts with the lightning and the blocked rain fog monkeys this first flowers attend that big wave hits from over there','2025-09-03 14:25:32');
INSERT INTO "audio_requests" VALUES(59,1403556244,'AwACAgIAAxkBAANBaLhQBlIZdZC1DILpg2Klnj2pBmYAAtWFAAJ2aMBJmuoAAU4b2KnTNgQ',288448,13.9735,'the entire arena seems to delay it off the clock with a new threat every hour but they stay only within the rich it all starts with the lightning then the blood rain fog monkeys that''s the first flowers attend that begriff hits from over there','2025-09-03 14:26:25');
INSERT INTO "audio_requests" VALUES(60,5115957688,'AwACAgIAAxkBAANKaLhTxLDO7cGllVLpYAz9YS7fr_gAAjx_AALGU8FJurDFWMuEy0U2BA',9867,2.3535,'хуй залупа','2025-09-03 14:42:15');
INSERT INTO "audio_requests" VALUES(61,5389366665,'AwACAgIAAxkBAANlaLlgoWdinacQA8U3gxMWveLw0_YAAnt6AALjHchJFI8_3U4JDwg2BA',12729,3.1135,'привет я думаю это хорошо переводишь','2025-09-04 09:49:31');
INSERT INTO "audio_requests" VALUES(62,998775808,'AwACAgIAAxkBAANyaLl8R1hkKidCkCLvNR9cdH05tmoAAguCAAIPz8hJ8rOYX875RXA2BA',7110,1.6335,'привет меня зовут полина','2025-09-04 11:54:04');
INSERT INTO "audio_requests" VALUES(63,998775808,'AwACAgIAAxkBAAN1aLl9_8rtk8FvIS7GhpLUsYxXq8EAAiSCAAIPz8hJWkbzYxc-dDw2BA',19040,4.6535,'люблю грозу в начале мая когда весенний первый гром как бы резвяся играю грохочет в небе голубом','2025-09-04 11:54:47');
INSERT INTO "audio_requests" VALUES(64,998775808,'AwACAgIAAxkBAAN4aLl-pp13qees3RM-P8czx_hUh7sAAiyCAAIPz8hJRFzADupXYfU2BA',9428,2.2335,'запятая точка кавычки','2025-09-04 11:57:28');
INSERT INTO "audio_requests" VALUES(65,5389366665,'AwACAgIAAxkBAAOFaLmxOnPeRKEL8dpNznNEjA8wKskAAsmAAALjHchJsByONBGHcpQ2BA',20583,5.2735,'Проверка пунктуации надеюсь она работает.','2025-09-04 15:33:17');
INSERT INTO "audio_requests" VALUES(66,5389366665,'AwACAgIAAxkBAAOMaLmxb7acy0sMH2G8CHEM387LSCkAAs-AAALjHchJqQHj5vv1w0I2BA',25118,6.4735,'My name is sasha, but i''m leaving in russia.','2025-09-04 15:34:12');
INSERT INTO "audio_requests" VALUES(67,5389366665,'AwACAgIAAxkBAAORaLmxjTrjeD-UG92nZGdHidcDdLAAAtCAAALjHchJAjNBMalXDuo2BA',11044,2.7735,'So i am gay.','2025-09-04 15:34:38');
INSERT INTO "audio_requests" VALUES(68,5389366665,'AwACAgIAAxkBAAOWaLm1KZDHGYMXW03sgbBvkx2oYMkAAv2AAALjHchJt2_UOOS1aMM2BA',24732,6.2335,'Привет это проверка связи надеюсь ты понимаешь пунктуацию.','2025-09-04 15:50:06');
INSERT INTO "audio_requests" VALUES(69,5389366665,'AwACAgIAAxkBAAObaLm3FIft-nYFRusJC1TTw8bFBYUAAiOBAALjHchJZCLlj7HiaUE2BA',19866,4.9735,'Привет. Я надеюсь. Ты. Понимаешь, где. Нужно. Поставить. Точку, а, где. Запятую.','2025-09-04 15:58:17');
INSERT INTO "audio_requests" VALUES(70,5389366665,'AwACAgIAAxkBAAOeaLm5s0omcV4SEqrUnGi_FVSVwwUAAlmBAALjHchJEf7ZczVbq7Q2BA',18654,4.5535,'Привет. Я надеюсь. Ты. Понимаешь. Где. Нужно. Поставить. Точку, а. Где. Запятую.','2025-09-04 16:09:27');
INSERT INTO "audio_requests" VALUES(71,5389366665,'AwACAgIAAxkBAAOjaLm7Q4UBGjsAAWLbyNk8syd070hOAAKJgQAC4x3ISclRDdSu0XSRNgQ',17712,4.2935,'Привет я надеюсь ты понимаешь где нужно поставить запятую а где точку.','2025-09-04 16:16:08');
INSERT INTO "audio_requests" VALUES(72,5389366665,'AwACAgIAAxkBAAOoaLnJH8wainAZmFmzzS_KetBvKdgAApeCAALjHchJwAM7Qv-nc902BA',24481,6.0335,'атуи и оеатки: ривет то раверка сви  надес онимае оставит току и атуи.','2025-09-04 17:15:17');
INSERT INTO "audio_requests" VALUES(73,5389366665,'AwACAgIAAxkBAAOvaLnJwPUdmrtLZEGDJajc3nnfSCcAAqSCAALjHchJ-jNGL1ZDfqo2BA',40530,10.5935,'hello, my name is sasha. i''m not even in russia, but i''m iranian, air, english','2025-09-04 17:17:58');
INSERT INTO "audio_requests" VALUES(74,5389366665,'AwACAgIAAxkBAAO2aLnK1UMXBUjSBKkMfuse4xa50a0AAraCAALjHchJbeN0nyIyI5s2BA',28846,7.4335,'Привет. Я надеюсь, ты понимаешь, куда поставить правильно запятую, а куда ставить точку.','2025-09-04 17:22:42');
INSERT INTO "audio_requests" VALUES(75,5288263305,'AwACAgIAAxkBAAPBaLnLL4lw1A4zJF8vqrtloMe_v1kAAth7AALgbdBJH90UI8DzXyk2BA',26817,6.7535,'I like strawberry banana mango and potatoes.','2025-09-04 17:24:02');
INSERT INTO "audio_requests" VALUES(76,5288263305,'AwACAgIAAxkBAAPEaLnLZGAxRWkLVzB_ASguR9gxqYsAAtp7AALgbdBJzEPQ23WeCvM2BA',12704,3.0135,'I didn''t even cry, but it tried to fake it.','2025-09-04 17:24:55');
INSERT INTO "audio_requests" VALUES(77,5288263305,'AwACAgIAAxkBAAPHaLnLwrXtoQABlo_ZMp7GMsklnc8eAALiewAC4G3QSXXuzyuW13MONgQ',20531,4.9535,'I miss our old games and food i love them very much.','2025-09-04 17:26:30');
INSERT INTO "audio_requests" VALUES(78,5389366665,'AwACAgIAAxkBAAPOaLnM2ctZc3AySTp7_KxT1PIJ8kQAAueCAALjHchJ1suKaoBysQABNgQ',20492,5.2935,'I''m stressing a kit cause i like it.','2025-09-04 17:31:08');
INSERT INTO "audio_requests" VALUES(79,5389366665,'AwACAgIAAxkBAAPTaLnNGSw83YWkgzvHX5VdMa2mglcAAu6CAALjHchJ9FO2v26MiPI2BA',15929,3.9135,'I love apples because they are sweet.','2025-09-04 17:32:12');
INSERT INTO "audio_requests" VALUES(80,5288263305,'AwACAgIAAxkBAAPWaLnNf3rvblCouk181zHILxUUBSgAAvx7AALgbdBJy7KGTAEF2ls2BA',27539,7.1335,'I like him because he''s handsome and fredy.','2025-09-04 17:33:53');
INSERT INTO "audio_requests" VALUES(81,5288263305,'AwACAgIAAxkBAAPZaLnNoC_QKQXzMUoCtsjaAAF-a3RwAAILiQAChGbJSTXAQWEmbsEdNgQ',17828,4.3735,'I like him cuz he''s handsome and greedy.','2025-09-04 17:34:27');
INSERT INTO "audio_requests" VALUES(82,5288263305,'AwACAgIAAxkBAAPcaLnNruJDLvwGG7Sxys1ttabC66UAAgyJAAKEZslJ7l-69d-ZL642BA',21317,5.2935,'I like him because he''s handsome and pretty.','2025-09-04 17:34:39');
INSERT INTO "audio_requests" VALUES(83,5288263305,'AwACAgIAAxkBAAPhaLnN2iJcpmDB498jjwakvIDWei8AAhCJAAKEZslJZPNgS2PSH9s2BA',29738,7.7135,'She has blue eyes black hair and white teeth.','2025-09-04 17:35:26');
INSERT INTO "audio_requests" VALUES(84,5389366665,'AwACAgIAAxkBAAPkaLnN6nbn-6hBXAxRu4EcZSsoc-4AAlmTAAKZlNFJxoR3s57ShoI2BA',44285,11.5335,'I love apples because they are sweet also i love fall paper because they are spicy.','2025-09-04 17:35:43');
INSERT INTO "audio_requests" VALUES(85,1779818320,'CQACAgIAAxkBAAPqaLpJdNEtvoDUZwGLivnDuaJy6S8AAj53AAKf7NBJijmb4U5rbbo2BA',89320,10.197313,'Город засыпает, на улицы города выходят лишь самые отважные и бесстрашные','2025-09-05 02:25:39');
INSERT INTO "audio_requests" VALUES(86,5389366665,'AwACAgIAAxkBAAPyaLpkWrCdbJTb86kmI_qFTdU273UAAg12AAKZlNlJ28gSZpPG7qs2BA',69753,17.4735,'Было бы заниматься, что дилеры.','2025-09-05 04:21:55');
INSERT INTO "audio_requests" VALUES(87,5389366665,'DQACAgIAAxkBAAP1aLpnvaznSxM_bOQ7MV7demXLy74AAnx1AALNY9FJcecvAsSXEyg2BA',637918,5,'В сети это просто ад.','2025-09-05 04:32:03');
INSERT INTO "audio_requests" VALUES(88,5389366665,'DQACAgIAAxkBAAP4aLpn4xVqC-YT0w549-4dxAEGwK8AAr92AAJCnrhJVRYOHk-D93M2BA',500931,4,'У вас непременно, а я вот пизду.','2025-09-05 04:32:39');
INSERT INTO "audio_requests" VALUES(89,5389366665,'AwACAgIAAxkBAAP_aLpxaj_XyaMGW5C4e2PA2u0XdfQAApt2AAKZlNlJVl7Z2c6P4cI2BA',38583,10.0535,'Пётр Пётр.','2025-09-05 05:13:29');
INSERT INTO "audio_requests" VALUES(90,5389366665,'AwACAgIAAxkBAAO2aLnK1UMXBUjSBKkMfuse4xa50a0AAraCAALjHchJbeN0nyIyI5s2BA',28846,7.4335,'Привет. Я надеюсь, ты понимаешь, куда поставить правильно запятую, куда ставить точку.','2025-09-05 05:14:07');
INSERT INTO "audio_requests" VALUES(91,5389366665,'DQACAgIAAxkBAAP1aLpnvaznSxM_bOQ7MV7demXLy74AAnx1AALNY9FJcecvAsSXEyg2BA',637918,5,'Это просто ад.','2025-09-05 05:14:42');
INSERT INTO "audio_requests" VALUES(92,5389366665,'DQACAgIAAxkBAAP4aLpn4xVqC-YT0w549-4dxAEGwK8AAr92AAJCnrhJVRYOHk-D93M2BA',500931,4,'Вас непременно, а я пишу.','2025-09-05 05:15:12');
INSERT INTO "audio_requests" VALUES(93,5389366665,'AwACAgIAAxkBAAIBC2i6ctrPPAk7X9SWbQhwBUtkxqtUAAIjiAACilPQScgXO1jUFbV_NgQ',66925,16.8735,'Ты банально реально знаешь раньше, когда не задумываешься в историю ещё что-то, как-то уснуть.','2025-09-05 05:19:36');
INSERT INTO "audio_requests" VALUES(94,5389366665,'AwACAgIAAxkBAAIBDmi6dMfAZdKL2wHbI7XsCCe-jMgyAAIjfgACcufQScUNh-4_ZMX1NgQ',15829,3.9335,'Для этого вот тоже мотылька используется, другая уже.','2025-09-05 05:27:40');
INSERT INTO "audio_requests" VALUES(95,5389366665,'AwACAgIAAxkBAAIBGWi6jFgTmUzzFztwFnl7kJSSyChLAAIHeAACmZTZSaF1x8CSVasZNgQ',12310,2.9335,'привет это проверка связи','2025-09-05 07:08:11');
INSERT INTO "audio_requests" VALUES(96,5389366665,'AwACAgIAAxkBAAIBHGi6jtwJXaF8vgTZI0j1tcJwajISAAI_eAACmZTZSSOYe5ICoDfJNgQ',42195,10.9135,'Я надеюсь понял что это несколько предложений в одном голосовом сообщении.','2025-09-05 07:18:56');
INSERT INTO "audio_requests" VALUES(97,5389366665,'DQACAgIAAxkBAAIBH2i6j04qfPa9f-KEOe8ptGfEch74AAJDeAACmZTZSa0rap5uEV-5NgQ',708702,6,'Проверка сможешь ли ты перевести текст из кружочка.','2025-09-05 07:20:49');
INSERT INTO "audio_requests" VALUES(98,5389366665,'AwACAgIAAxkBAAIBJGi6kypOvxU8whKzFeKtSFMKAAFgTAACb3gAApmU2UnVmulI_oO1jzYE',31043,7.8535,'Привет. Это проверка для того, чтобы понять, понимаешь ли ты, где ставить запятую, а где точку.','2025-09-05 07:37:27');
INSERT INTO "audio_requests" VALUES(99,5389366665,'AwACAgIAAxkBAAIBN2i7xJOGarcVuH5IvSrNBPwWSt59AAKyeAACrwHhSQgd_HjlXMPSNgQ',41592,10.4935,'«Блядь, я думала, что мы с двенадцати до десяти.','2025-09-06 05:20:29');
INSERT INTO "audio_requests" VALUES(100,5389366665,'AwACAgIAAxkBAAIBN2i7xJOGarcVuH5IvSrNBPwWSt59AAKyeAACrwHhSQgd_HjlXMPSNgQ',41592,10.4935,'Позже мне кажется, что все равно не опоздаю, потому что пробок нет.','2025-09-06 05:21:29');
INSERT INTO "audio_requests" VALUES(101,5389366665,'AwACAgIAAxkBAAIBN2i7xJOGarcVuH5IvSrNBPwWSt59AAKyeAACrwHhSQgd_HjlXMPSNgQ',41592,10.4935,'Позже мне кажется, что все равно не опоздаю, потому что пробок нет.','2025-09-06 05:21:59');
INSERT INTO "audio_requests" VALUES(102,5389366665,'AwACAgIAAxkBAAIBQGi72KcWXTiu5uoKHw5iyKQkOzgWAAI4cwACUwAB4Em2AAGKRZwbFZw2BA',24505,6.1335,'Привет. Я надеюсь, ты понимаешь, как правильно ставить точки, как правильно ставить запятые.','2025-09-06 06:46:10');
INSERT INTO "audio_requests" VALUES(103,5389366665,'AwACAgIAAxkBAAIBRWi9b6WkVRw_Pna-r7EqNJ-MmG0rAAJUeQACUwAB8ElxDiv9wMT4NTYE',15041,3.7335,'Что светят солнца Ещё раз: на улице светит солнце.','2025-09-07 11:42:45');
INSERT INTO "audio_requests" VALUES(104,5115957688,'AwACAgIAAxkBAAIBSmi9o9WUGJ8VtGLaJxGnKqbjentqAALzeAACKOrwSZovGY4LsKw5NgQ',538913,26.1135,'И потом губим на вторые права и покупаем себе Ладу Приору. Чтобы она была не настолько убитая, садим её в ноль до нивы в чёрный.','2025-09-07 15:25:44');
CREATE TABLE batch_processing (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    batch_id TEXT UNIQUE,
                    total_files INTEGER,
                    processed_files INTEGER,
                    status TEXT CHECK(status IN ('processing', 'completed', 'failed')),
                    result_path TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );
CREATE TABLE feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    request_id INTEGER,
                    rating INTEGER CHECK(rating IN (1, 2, 3, 4, 5)),
                    comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (request_id) REFERENCES audio_requests (id)
                );
CREATE TABLE requests (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        file_size INTEGER,
                        duration REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    );
CREATE TABLE users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
INSERT INTO "users" VALUES(474347307,'anutickus','Аня',NULL,'2025-09-03 14:03:56');
INSERT INTO "users" VALUES(673344519,'kallinnaaa','Аина 🧸',NULL,'2025-09-03 14:19:09');
INSERT INTO "users" VALUES(673719450,NULL,'Romartie',NULL,'2025-09-03 14:41:15');
INSERT INTO "users" VALUES(685827385,'Lou_Carcolhh','Cuélebre','Lehen','2025-09-01 05:06:09');
INSERT INTO "users" VALUES(717285663,'Daari_kk','Дарья','Нерозя','2025-09-03 14:21:56');
INSERT INTO "users" VALUES(883598621,'mirmint','Анастасия',NULL,'2025-09-03 14:14:20');
INSERT INTO "users" VALUES(897564455,'doplis','Dashulya',NULL,'2025-09-03 13:59:07');
INSERT INTO "users" VALUES(918116959,'lxnamrr','Маргарита',NULL,'2025-09-03 15:00:37');
INSERT INTO "users" VALUES(920233004,'tchamfx','ѕαѕнα',NULL,'2025-09-01 07:51:02');
INSERT INTO "users" VALUES(928479553,'Dez0ter','Дезокер',NULL,'2025-09-01 08:15:15');
INSERT INTO "users" VALUES(931836227,'nast_ena20','Настена',NULL,'2025-09-03 14:05:57');
INSERT INTO "users" VALUES(941113842,'blesswards','enxxxx',NULL,'2025-08-31 16:17:53');
INSERT INTO "users" VALUES(974556405,'kiptok','Sergey','Kipyatkov','2025-08-31 16:19:38');
INSERT INTO "users" VALUES(998775808,'Izyaction','Поля',NULL,'2025-09-01 06:32:09');
INSERT INTO "users" VALUES(1013833242,'Tomatocha','Иришка 💕',NULL,'2025-09-01 05:05:44');
INSERT INTO "users" VALUES(1025864298,'Viskihh','vissski',NULL,'2025-09-04 06:44:42');
INSERT INTO "users" VALUES(1088667912,'Elena_Kipyatkova','Елена','Кипяткова','2025-08-31 16:21:30');
INSERT INTO "users" VALUES(1403556244,'alukash2002','Санечка',NULL,'2025-09-03 14:23:34');
INSERT INTO "users" VALUES(1725802029,'Tokyolovv','Антон',NULL,'2025-09-04 06:44:42');
INSERT INTO "users" VALUES(1779818320,'nzrappn','Лиза',NULL,'2025-09-01 05:05:48');
INSERT INTO "users" VALUES(1793460299,'vss9_17','яваря',NULL,'2025-09-04 06:44:43');
INSERT INTO "users" VALUES(5115957688,'naszwlqs','анастасия',NULL,'2025-09-03 14:42:01');
INSERT INTO "users" VALUES(5288263305,'ness_klg','асяся',NULL,'2025-08-31 16:33:51');
INSERT INTO "users" VALUES(5389366665,'kipyatoook','Саша',NULL,'2025-08-31 15:22:13');
INSERT INTO "users" VALUES(6242110030,'annwelco','Д᧐ᥴᴛ_κун',NULL,'2025-08-31 16:19:49');
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('audio_requests',104);
INSERT INTO "sqlite_sequence" VALUES('admin_sessions',18);
COMMIT;
